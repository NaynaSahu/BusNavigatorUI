<!DOCTYPE html>
<html>
<head>
	<title>Bus Navigator Website</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
		<h1>Bus Navigator</h1>
		<nav>
			<ul>
				<li><a href="#">Home</a></li>
				<li><a href="#">About Us</a></li>
				<li><a href="#">Routes</a></li>
				<li><a href="#">Timetables</a></li>
				<li><a href="#">Contact Us</a></li>
			</ul>
		</nav>
	</header>
	<main>
		<section class="hero">
			<h2>Find Your Bus Route</h2>
			<form>
				<input type="text" placeholder="Enter Starting Location">
				<input type="text" placeholder="Enter Destination">
				<button type="submit">Search</button>
			</form>
		</section>
		<section class="about-us">
			<h2>About Us</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed viverra orci id magna congue venenatis. Donec rutrum massa id risus volutpat dictum. Sed nec luctus dolor. Praesent vestibulum neque eget felis bibendum euismod. Nulla malesuada velit sit amet sem pellentesque, ac molestie orci maximus. Donec vitae lacus neque. Suspendisse auctor ipsum sit amet faucibus rutrum.</p>
		</section>
		<section class="routes">
			<h2>Routes</h2>
			<ul>
				<li><a href="#">Route 1</a></li>
				<li><a href="#">Route 2</a></li>
				<li><a href="#">Route 3</a></li>
				<li><a href="#">Route 4</a></li>
				<li><a href="#">Route 5</a></li>
			</ul>
		</section>
		<section class="timetables">
			<h2>Timetables</h2>
			<ul>
				<li><a href="#">Timetable 1</a></li>
				<li><a href="#">Timetable 2</a></li>
				<li><a href="#">Timetable 3</a></li>
				<li><a href="#">Timetable 4</a></li>
				<li><a href="#">Timetable 5</a></li>
			</ul>
		</section>
	</main>
	<footer>
		<p>&copy; 2023 Bus Navigator. All rights reserved.</p>
	</footer>
</body>
</html>
